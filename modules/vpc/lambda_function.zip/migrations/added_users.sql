CREATE TABLE migrations (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100)
);

INSERT INTO migrations (name)
VALUES
    ('Gurgen'), 
    ('Serob'), 
    ('Narek'), 
    ('Misha'), 
    ('Arman'), 
    ('Yura');
