CREATE TABLE migrations (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100)
);
